package com.yash.yashclientmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.yashclientmanagement.entity.Client;
import com.yash.yashclientmanagement.exception.ClientNotFoundException;
import com.yash.yashclientmanagement.repository.ClientRepository;
@CrossOrigin("http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class ClientController {
	
	@Autowired
	private ClientRepository clientRepository;
	
	@GetMapping("/clients")
	public List<Client> getClients(){
		
		return clientRepository.findAll();
		
	}
	
	@PostMapping("/clients")
	public Client createClient(@RequestBody Client client) {
		System.out.println("Client Object=>"+client);
		return clientRepository.save(client);
	}
	@GetMapping("/clients/{clientId}")
	public ResponseEntity<Client> getClientById(@PathVariable Long clientId) {
		  Client client = clientRepository.findById(clientId).orElseThrow(()->new ClientNotFoundException("Client is not found with id"+clientId));
	return ResponseEntity.ok(client);
	}
	
	@PutMapping("/clients/{clientId}")
	public ResponseEntity<Client> updateClient(@PathVariable Long clientId,@RequestBody Client clientRequest){
		Client client = clientRepository.findById(clientId).orElseThrow(()->new ClientNotFoundException("Client is not found with id"+clientId));
		
		 client.setClientName(clientRequest.getClientName());
		 client.setYashPerson(clientRequest.getYashPerson());
		 client.setClientPerson(clientRequest.getClientPerson());
		 client.setStartDate(clientRequest.getStartDate());
		 client.setEndDate(clientRequest.getEndDate());
		 client.setIsActive(clientRequest.getIsActive());
		 Client clientObj = clientRepository.save(client);
		 return ResponseEntity.ok(clientObj);
	}
	@DeleteMapping("/clients/{clientId}")
	public ResponseEntity<String> deleteClient(@PathVariable Long clientId){
		Client client = clientRepository.findById(clientId).orElseThrow(()->new ClientNotFoundException("Client is not found with id"+clientId));
		clientRepository.delete(client);
		return ResponseEntity.ok("Client Delete Succefully");
	}
	


}
