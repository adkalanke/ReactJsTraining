package com.yash.yashclientmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YashClientManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(YashClientManagementApplication.class, args);
	}

}
