package com.yash.yashclientmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YashClientManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
